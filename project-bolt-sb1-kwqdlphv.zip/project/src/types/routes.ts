export interface Route {
  path: string;
  title: string;
  description?: string;
}